package com.example.myjavaapplicationpractice;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) { // onCreate를 통해서 호출을 시작한다. main과 유사하다.
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login); // setContentView 내부에 작성한 코드를 실행할 수 있다. & activity_main과 매칭되어서 사용된다.
    }
}